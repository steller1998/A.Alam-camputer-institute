const menuToggle=document.querySelector(".menu-toggle");const nav=document.querySelector(".nav-links");menuToggle?.addEventListener("click",()=>nav.classList.toggle("open"));document.querySelectorAll(".nav-links a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("visible")}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

const glow=document.querySelector(".cursor-glow");window.addEventListener("pointermove",e=>{glow.style.left=e.clientX+"px";glow.style.top=e.clientY+"px"});

const items=[...document.querySelectorAll(".gallery-item")];const lightbox=document.getElementById("lightbox");const img=document.getElementById("lightbox-img");let index=0;
function show(i){index=(i+items.length)%items.length;img.src=items[index].dataset.full;img.alt=items[index].querySelector("img").alt;lightbox.classList.add("open");document.body.style.overflow="hidden"}
items.forEach((item,i)=>item.addEventListener("click",()=>show(i)));
document.querySelector(".close-lightbox").onclick=()=>{lightbox.classList.remove("open");document.body.style.overflow=""};
document.querySelector(".prev").onclick=()=>show(index-1);document.querySelector(".next").onclick=()=>show(index+1);
lightbox.addEventListener("click",e=>{if(e.target===lightbox){lightbox.classList.remove("open");document.body.style.overflow=""}});
window.addEventListener("keydown",e=>{if(!lightbox.classList.contains("open"))return;if(e.key==="Escape")document.querySelector(".close-lightbox").click();if(e.key==="ArrowLeft")show(index-1);if(e.key==="ArrowRight")show(index+1)});

document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener("click",e=>{const t=document.querySelector(a.getAttribute("href"));if(t){e.preventDefault();t.scrollIntoView({behavior:"smooth"})}}));
